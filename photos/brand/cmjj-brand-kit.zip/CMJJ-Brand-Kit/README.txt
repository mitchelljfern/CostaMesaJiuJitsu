Costa Mesa Jiu Jitsu brand kit (2026 octopus brand)

1-Logos        Full-color logo (3 sizes) and one-color versions: white, black, cyan.
2-Icons        App icon, profile picture, octopus head, favicons.
3-Elements     Tentacles, sucker ring and belt bar as SVG (scale to any size).
4-Colors-and-Fonts  Color codes and fonts. All fonts are free on Google Fonts.
5-Social       Link share image (1200 x 630) and profile picture.

Full guide with rules and examples: costamesajiujitsu.com/brand-kit
Questions: info@costamesajiujitsu.com
